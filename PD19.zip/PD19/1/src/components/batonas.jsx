import { useState } from 'react'

import Button from './ez.jsx'
import Header from './gal.jsx'

function Article() {
  return (
    <>
        <Header></Header>
        <p>ygfiegefiyewrfgfigfewiygfeiywfeg</p>
        <Button></Button>
    </>
  )
}

export default Article