import { useState } from 'react'



function App() {
  


    

 
  return (
    <>
  
      <button onClick={(e) => setPavadinimas("konkretus batonas")}  >mygtukas</button>
    
    </>
  )
}

export default App
