
import Button from './ez.jsx'


function Header() {
  return (
    <>
      <h1>hedddddas</h1>
      <Button />
    </>
  )
}

export default Header