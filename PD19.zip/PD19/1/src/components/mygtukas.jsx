import { useState } from 'react'



function App() {
  const [pavadinimas, setPavadinimas ]

   = useState("")
    
    

 
  return (
    <>
  
      <button onClick={(e) => setPavadinimas("konkretus batonas")}  >mygtukas</button>
      <p className="read-the-docs">
     {pavadinimas}
    
      </p>
    </>
  )
}

export default App
