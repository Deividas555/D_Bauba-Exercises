import { useState } from 'react'



function App() {
  const [pavadinimas, setPavadinimas ]

   = useState("")
    
    

 
  return (
    <>
  <nav>
    <h1><a href='https://www.delfi.lt/' >ss</a></h1>
    <h2><a a href='https://www.delfi.lt/'>s</a></h2>
    <h3><a href='https://www.delfi.lt/'>sss</a></h3>
  </nav>
   
    
    
    </>
  )
}

export default App
